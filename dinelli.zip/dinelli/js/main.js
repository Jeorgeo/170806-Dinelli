
//*require fancybox

$(document).ready(function(){
  $(".show_modal").fancybox({
    type: 'inline',
    padding : 20,
    content: $('#modal')
  });



});

//*require WOW effects

/*new WOW().init();*/
